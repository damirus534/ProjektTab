package pl.polsl.ProjektTab;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjektTabApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjektTabApplication.class, args);
	}

}
