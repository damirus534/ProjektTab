package pl.polsl.ProjektTab;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjektTabApplicationTests {

	@Test
	void contextLoads() {
	}

}
